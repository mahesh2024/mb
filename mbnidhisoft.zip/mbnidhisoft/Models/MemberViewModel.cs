﻿using mb.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace mbnidhisoft.Models
{
    public class MemberViewModel
    {
        public List<MemberInfo> MemberInfos { get; set; }
        public MemberViewModel()
        {
            MemberInfos = new List<MemberInfo>();
        }
        public void Initialize()
        {
            LoadMembers();
        }

        private void LoadMembers()
        {
            for (int i = 0; i < 100; i++)
            {
                MemberInfos.Add(new MemberInfo()
                {
                    Id = i,
                    MembershipNo = string.Format("11000{0}", i),
                    CreationDate = DateTime.Now.AddDays(-i),
                    DOB = new DateTime(1987, 05, 27),
                    Name = string.Format("Member_{0}", i),
                    Address = new AddressInfo()
                    {
                        Phone1 = "9999999999",
                        Phone2 = "6666666666",
                        City = "Bangalore",
                        State = "KA",
                        Id = i
                    }
                });
            }
        }
    }
}