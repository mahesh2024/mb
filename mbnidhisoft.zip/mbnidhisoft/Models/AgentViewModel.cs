﻿using mb.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mbnidhisoft.Models
{
    public class AgentViewModel
    {
        public List<AgentInfo> Agents
        {
            get; set;
        }
        public AgentViewModel()
        {
            Agents = new List<AgentInfo>();
        }

        public void Initialize()
        {
            LoadAgents();
        }

        private void LoadAgents()
        {
            for (int i = 0; i < 3; i++)
            {
                Agents.Add(new AgentInfo()
                {
                    Id = i,
                    Name = string.Format("Agent{0}", i),
                    AgentCode = string.Format("MBA720{0}", i),
                    BranchCode = "720",
                    BranchName = "Jayangar"
                });
            }
        }
    }
}