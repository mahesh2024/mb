﻿using mb.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mbnidhisoft.Models
{
    public class AccountViewModel
    {
        public List<Accounts> AccountDetails { get; set; }
        public AccountViewModel()
        {

        }
        public void Initialize()
        {

        }
        private void LoadAccountDetail()
        {
        }
    }
}