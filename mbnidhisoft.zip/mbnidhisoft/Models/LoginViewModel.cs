﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mbnidhisoft.Models
{
    public class LoginViewModel
    {
        public string Login { get; set; }
        public string Password { get; set; }
    }
}