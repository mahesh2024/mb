﻿using mbnidhisoft.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace mbnidhisoft.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account
        [HttpGet]
        [AllowAnonymous]
        public ActionResult Login()
        {
            var longviewModel = new LoginViewModel();
            return View(longviewModel);
        }
        [HttpPost]
        [AllowAnonymous]
        public ActionResult Login(LoginViewModel loginViewmodel, string returnUrl)
        {
            var username = loginViewmodel.Login;
            var pass = loginViewmodel.Password;
            bool userValid = true;

            // User found in the database
            if (userValid)
            {

                FormsAuthentication.SetAuthCookie(username, false);
                if (Url.IsLocalUrl(returnUrl) && returnUrl.Length > 1 && returnUrl.StartsWith("/")
                    && !returnUrl.StartsWith("//") && !returnUrl.StartsWith("/\\"))
                {
                    return Redirect(returnUrl);
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
            }
            else
            {
                ModelState.AddModelError("", "The user name or password provided is incorrect.");
            }
            return View(loginViewmodel);
        }

        public ActionResult LogOff()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }

    }
}