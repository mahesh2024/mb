﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mbnidhisoft.business.models
{
    public class UserInfo
    {
        public int Id { get; set; }
        public int UserType { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public DateTime CreatedOn { get; set; }
        public bool IsUserActive { get; set; }
    }
}