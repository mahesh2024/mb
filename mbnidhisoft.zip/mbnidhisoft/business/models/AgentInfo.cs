﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mb.models
{
    public class AgentInfo
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string AgentCode { get; set; }
        public string BranchName { get; set; }
        public string BranchCode { get; set; }
        public int AddressId { get; set; }
        public AddressInfo Address { get; set; }
    }
}
