﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mb.models
{
    public enum AccountType
    {
        DEPOSIT,
        LOAN
    }
    public class Accounts
    {
        public int Id { get; set; }
        public string MembershipNo { get; set; }
        public int AccountType { get; set; }
        public DateTime OpeningDate { get; set; }
        public DateTime ClosingDate { get; set; }
        public decimal PrincipalAmount { get; set; }
        public decimal OutstandingAmount { get; set; }
        public decimal TotalInterest { get; set; }
        public decimal InterestRate { get; set; }
        public List<CollectionInfo> Collections { get; set; }
    }
}
