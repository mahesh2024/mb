﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mb.models
{
    public class CollectionInfo
    {
        public int Id { get; set; }
        public DateTime CollectionDate { get; set; }
        public decimal CollectionAmount { get; set; }
        public int CollectionMode { get; set; }
        public int AgentId { get; set; }
        public AgentInfo AgentDetail { get; set; }
    }
}
