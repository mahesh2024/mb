﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mb.models
{
    public enum NomineeRelation
    {
        SPOUSE = 1,
        DAUGHTER = 2,
        SON = 3,
        MOTHER = 4,
        FATHER = 5,
        BROTHER = 6,
        SISTER = 7
    }
    public class MemberInfo
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime DOB { get; set; }
        public string MembershipNo { get; set; }
        public DateTime CreationDate { get; set; }
        public DateTime ClosingDate { get; set; }
        public string Nominee { get; set; }
        public int NomineeRelation { get; set; }
        public string AdhaarNo { get; set; }
        public string PanNo { get; set; }
        public bool IsActive { get; set; }
        public int AddressId { get; set; }
        public string IntroducerMembershipNo { get; set; }
        public AddressInfo Address { get; set; }
    }
}
